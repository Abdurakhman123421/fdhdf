const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('database.db', (err) => {
if (err) {
console.error(err.message);
}
console.log('Connected to the database.');
});

// Создание таблиц для магазина
db.serialize(() => {
// Таблица "Поставщики"
db.run(`CREATE TABLE IF NOT EXISTS suppliers (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
inn TEXT,
address TEXT,
phone TEXT
)`);

// Таблица "Клиенты"
db.run(`CREATE TABLE IF NOT EXISTS customers (
id INTEGER PRIMARY KEY AUTOINCREMENT,
fio TEXT,
email TEXT,
address TEXT,
phone TEXT
)`);

// Таблица "Товары"
db.run(`CREATE TABLE IF NOT EXISTS products (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
price REAL,
description TEXT,
rating REAL
)`);

// Таблица "Ассортимент товара"
db.run(`CREATE TABLE IF NOT EXISTS product_assortment (
id INTEGER PRIMARY KEY AUTOINCREMENT,
product_id INTEGER,
supplier_id INTEGER,
FOREIGN KEY (product_id) REFERENCES products (id),
FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
)`);

// Таблица "Заказ"
db.run(`CREATE TABLE IF NOT EXISTS orders (
id INTEGER PRIMARY KEY AUTOINCREMENT,
customer_id INTEGER,
pickup_point_id INTEGER,
issue_date TEXT,
FOREIGN KEY (customer_id) REFERENCES customers (id),
FOREIGN KEY (pickup_point_id) REFERENCES pickup_points (id)
)`);

// Таблица "Пункт выдачи"
db.run(`CREATE TABLE IF NOT EXISTS pickup_points (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
address TEXT,
phone TEXT
)`);

// Таблица "Роли"
db.run(`CREATE TABLE IF NOT EXISTS roles (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT
)`);

// Таблица "Сотрудники"
db.run(`CREATE TABLE IF NOT EXISTS employees (
id INTEGER PRIMARY KEY AUTOINCREMENT,
fio TEXT,
passport TEXT,
address TEXT,
phone TEXT,
pickup_point_id INTEGER,
rating REAL,
role INTEGER,
username TEXT,
password TEXT,
salary REAL,
FOREIGN KEY (pickup_point_id) REFERENCES pickup_points (id),
FOREIGN KEY (role) REFERENCES roles (id)
)`);

// Таблица "Состав заказа"
db.run(`CREATE TABLE IF NOT EXISTS order_items (
id INTEGER PRIMARY KEY AUTOINCREMENT,
product_id INTEGER,
order_id INTEGER,
quantity INTEGER,
FOREIGN KEY (product_id) REFERENCES products (id),
FOREIGN KEY (order_id) REFERENCES orders (id)
)`);
});