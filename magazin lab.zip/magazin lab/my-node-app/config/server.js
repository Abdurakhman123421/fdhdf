const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public'))); // Обслуживание статических файлов

// Обработка корневого маршрута
app.get('/', (req, res) => {
res.sendFile(path.join(__dirname, '../public', 'index.html'));
});

// Остальные маршруты (например, для регистрации)
app.post('/register', (req, res) => {
// Ваш код для регистрации
});

// Запуск сервера
app.listen(PORT, () => {
console.log(`Сервер запущен на http://localhost:${PORT}`);
});