// Удаление товара
exports.deleteProduct = (req, res) => {
    const { id } = req.params;
    
    db.run(`DELETE FROM products WHERE id = ?`, [id], function(err) {
    if (err) {
    return res.status(500).json({ message: 'Ошибка удаления товара.' });
    }
    if (this.changes === 0) {
    return res.status(404).json({ message: 'Товар не найден.' });
    }
    res.json({ message: 'Товар удален.' });
    });
    };